package com.Building;

public class JsonData{

}

